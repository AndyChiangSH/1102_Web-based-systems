from django.contrib import admin
from .models import HW7

# Register your models here.
admin.site.register(HW7)