from django.contrib import admin
from .models import NewTable, Product

# Register your models here.
admin.site.register(NewTable)
admin.site.register(Product)