from django.apps import AppConfig


class DiningBriefConfig(AppConfig):
    name = 'dining_brief'
