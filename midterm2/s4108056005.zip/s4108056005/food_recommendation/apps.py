from django.apps import AppConfig


class FoodRecommendationConfig(AppConfig):
    name = 'food_recommendation'
